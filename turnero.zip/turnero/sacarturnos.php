<!DOCTYPE html>
<html style="max-width: 100%; overflow-x: hidden;" lang="en">
<!-- Basic -->

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, minimum-scale=0.3, initial-scale=0.3">

  <!-- Site Metas -->
  <title>Sacar Turnos-Formar</title>
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Site Icons -->
  <link rel="shortcut icon" href="/images/formarico.png" type="image/x-icon">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/css/bootstrap.min.css">
  <!-- Pogo Slider CSS -->
  <!-- Site CSS -->
  <link rel="stylesheet" href="/css/styleav.css">
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="/css/responsive.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="/css/custom.css">
  <!-- Desplegable -->
  <link rel="stylesheet" href="/css/dropdown.css">
  <!-- Navar -->
  <link rel="stylesheet" href="/css/navvar.css">
  <!-- AulaVirtual -->
  <link rel="stylesheet" href="/css/aulavirtual.css">
  <!-- Icons -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/v4-shims.css">  

  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body id="home" style="position: relative; width:100%; max-width: 100%; overflow-x: hidden;" data-spy="scroll" data-target="#navbar-wd" data-offset="98">

  <!-- LOADER -->
  <div id="preloader">
    <div class="loader">
      <img src="/images/loader.gif" alt="#" />
    </div>
  </div>
  <!-- end loader -->
  <!-- END LOADER -->

  <!-- Start header -->
  <header class="top-header">
    <nav class="navbar header-nav navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="inicio"><img id="logo" src="/images/logo.png" alt="image"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
          <span></span>
          <span></span>
          <span></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
            <ul class="nav">
            
            <?php
            session_start();
            if(isset($_SESSION['vip'])){
                echo'
                <li><a class="nav-link" href="turnos">Turnos Dados</a></li>
                <li><a class="nav-link" href="registrarprofesional">Registrar Profesionales</a></li>
                <li><a class="nav-link" href="registrarpaciente">Registrar Pacientes</a></li>
                <li><a class="nav-link" href="cerrar_sesion_be">Cerrar Sesion</a></li>
                ';
            }
            ?>
        
          </ul>
        </div>
      </div>
    </nav>
  </header>
<div align="center">
    <div style="text-align:center; display: block; position: relative; width: auto;">
  <hr>
  <h2>Fechas Disponibles - FORMAR</h2>

<form method="POST" action="sacarturnos">
<br>
<input type="date" name="fecha" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 20%;">
<br>
<select name="profesional" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 20%;">
    <?php
                include 'conexionturno_be.php';
                $sqlprofesional = mysqli_query($conexion, "SELECT * FROM profesionales");
                $rowprofesional = mysqli_num_rows($sqlprofesinal);
                echo '<option selected>Profesional</option>';
                while ($rowprofesional = mysqli_fetch_array($sqlprofesional)){
                echo "
                <option value='".$rowprofesional['nombre_completo'] ."'>" .$rowprofesional['nombre_completo'] . ' - MP.' .$rowprofesional['matricula']."</option>" ;
                }
                ?>
</select>
<br>
                                            <br>
					<input type="submit" name="comprobar" placeholder="Comprobar" style="background-color: #7ba4e3; color: white; border-radius: 10px;">
					<br>
					
	<?php
	include 'conexionturno_be.php';
	
	
	if(isset($_POST['comprobar'])){
	    
	    $sqlvalFecha = mysqli_query($conexion, "SELECT * FROM turnos WHERE fecha_tomada='{$_POST['fecha']}' AND nombre_profesional='{$_POST['profesional']}'");
	    $queryvalFecha = mysqli_query($conexion, $sqlvalFecha);
            echo '
            <br>
           <h3>El dia '.$_POST['fecha'].' los horarios <span style="color: red;">ocupados</span> son: </h3>';
	        foreach($sqlvalFecha as $fecha){
	           
	           echo "<option style='color: red' value='".$fecha['hora_tomada'] ."'>>" .$fecha['hora_tomada'] . " - Prof. " .$fecha['nombre_profesional'] . "</option>";

                }
        $sqlvalFecha1 = mysqli_query($conexion, "SELECT horarios FROM `horarios` as hs INNER JOIN turnos as t WHERE hs.horarios!=t.hora_tomada AND t.fecha_tomada='{$_POST['fecha']}' AND t.nombre_profesional='{$_POST['profesional']}' ");
	    $queryvalFecha1 = mysqli_query($conexion, $sqlvalFecha1);
            echo '
            <br>
           <h3>El dia '.$_POST['fecha'].' los horarios <span style="color: green;">disponibles</span> son: </h3>';
	        foreach($sqlvalFecha1 as $fecha1){
	            
	            
	           echo "<option style='color: green'>" .$fecha1['horarios']. " - Prof. " .$fecha['nombre_profesional']. "</option>";

                }      
	    }     if(empty($fecha['nombre_profesional'])){ echo 'No hay horarios ocupados';
	        
	    }      
	
	
	?>

</form>
  </div>
<div style="display: block; position: relative; width: 800px;">
  <hr>
  <h2>Turnero - FORMAR</h2>

  
<form method="POST" id="turno" action="sacarturnos_be.php">
<select name="paciente" id="paciente" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%">
        <?php
                include 'conexionturno_be.php';
                $sqlpaciente = mysqli_query($conexion, "SELECT * FROM pacientes");
                $rowpaciente = mysqli_num_rows($sqlpaciente);
                echo '<option selected>Paciente</option>';
                while ($rowpaciente = mysqli_fetch_array($sqlpaciente)){
                echo "
                <option value='".$rowpaciente['nombre_completo'] ."'>" .$rowpaciente['nombre_completo'] ."</option>" ;
                }
                ?>
    
</select>
<br>
<input type="email" name="email" id="email" placeholder="Ingrese su email" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%">
<br>
<a>Si no estas en la lista, registrate <a href="registrarpaciente">aqui</a></a>
<br>
<select name="obrasocial" id="obrasocial" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%">
        <?php
                include 'conexionturno_be.php';
                $sqlobra = mysqli_query($conexion, "SELECT * FROM pacientes");
                $rowobra = mysqli_num_rows($sqlobra);
                echo '<option selected="selected">Selecionar Obra Social</option>
                                            <option>APM</option>
                                            <option>Swiss Medical</option>
                                            <option>OSDE</option>
                                            <option>Luis Pasteur</option>
                                            <option>Apross</option>
                                            <option>Galeno</option>
                                            <option>ACA-Salud</option>
                                            <option>Prevencion Salud</option>
                                            <option>Visitar</option>
                                            <option>OSSEG</option>
                                            <option>Caja Notarial</option>
                                            <option>Caja de Abogados</option>
                                            <option>CPCE</option>
                                            <option>Daspu</option>
                                            <option>Federada Salud</option>';
                                            
                ?>
    
</select>
<br>
<select name="profesional" id="profesional" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
    <?php
                include 'conexionturno_be.php';
                $sqlprofesional = mysqli_query($conexion, "SELECT * FROM profesionales");
                $rowprofesional = mysqli_num_rows($sqlprofesinal);
                echo '<option selected>Profesional</option>';
                while ($rowprofesional = mysqli_fetch_array($sqlprofesional)){
                echo "
                <option value='".$rowprofesional['nombre_completo'] ."'>" .$rowprofesional['nombre_completo'] . ' - MP.' .$rowprofesional['matricula']."</option>" ;
                }
                ?>
</select>
<br>
<input type="date" name="fecha" id="fecha" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
<br>
<select name="hora" id="hora" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
    <option>9:00Hs</option>
    <option>9:45Hs</option>
    <option>10:30Hs</option>
    <option>11:15Hs</option>
    <option>12:00Hs</option>
    <option>12:45Hs</option>
    <option>13:30Hs</option>
    <option>14:15Hs</option>
    <option>15:00Hs</option>
    <option>15:45Hs</option>
    <option>16:30Hs</option>
    <option>17:15Hs</option>
</select>
<br>
<select name="prestacion" id="prestacion" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
    <option value="Estetica">Estetica</option>
    <option value="Ortodoncia">Ortodoncia</option>
    <option value="Ortopedia">Ortopedia</option>
    <option value="Cirugia">Cirugia</option>
    <option value="Endodoncia">Endodoncia</option>
    <option value="Protesis">Protesis</option>
    <option value="Periodoncia">Periodoncia</option>
</select>
<br>
                                            <br>
					<button placeholder="Registrar Turno" name="imprime" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Registrar Turno</button>
					<button name="imprimir" onclick="openWin()" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Imprimir Turno</button>
					

</form>
  </div>
  </div>  
</body>

<script type="text/javascript">
  function openWin()
  {
              document.getElementById('turno').onsubmit = function() { 
        	console.log(document.getElementById('paciente').value);
        	console.log(document.getElementById('profesional').value);
        	console.log(document.getElementById('obrasocial').value);
        	console.log(document.getElementById('fecha').value);
        	console.log(document.getElementById('hora').value);
        	console.log(document.getElementById('prestacion').value);
          return false;
        };
      var logo = '<img id="logo" src="/images/logo.png" alt="image"><br>';        
      var paciente = document.getElementById('paciente').value;
      var profesional = document.getElementById('profesional').value;
      var obrasocial = document.getElementById('obrasocial').value;
      var fecha = document.getElementById('fecha').value;
      var hora = document.getElementById('hora').value;
      var prestacion = document.getElementById('prestacion').value;
    var myWindow=window.open('','','width=400,height=300');
    myWindow.document.write(logo);
    myWindow.document.write('<h2>Turno</h2>');
    myWindow.document.write('Paciente: ' + paciente);
    myWindow.document.write('<br>Profesional: ' + profesional);
    myWindow.document.write('<br>Obra Social: ' + obrasocial);
    myWindow.document.write('<br>Fecha: ' + fecha);
    myWindow.document.write('<br>Hora: ' + hora);
    myWindow.document.write('<br>Prestacion: ' + prestacion);
    
    myWindow.document.close();
myWindow.focus();
myWindow.print();
myWindow.close();
    
  }
</script>

  <script src="/js/jquery.min.js"></script>
  <script src="/js/popper.min.js"></script>
  <script src="/js/bootstrap.min.js"></script>
  <!-- ALL PLUGINS -->
  <script src="/js/jquery.magnific-popup.min.js"></script>
  <script src="/js/jquery.pogo-slider.min.js"></script>
  <script src="/js/smoothscroll.js"></script>
  <script src="/js/isotope.min.js"></script>
  <script src="/js/images-loded.min.js"></script>
  <script src="/js/custom.js"></script>
    <script src="/js/togglefullscreen.js"></script>
</body>

</html>