<!DOCTYPE html>
<html style="max-width: 100%; overflow-x: hidden;" lang="en">
<!-- Basic -->

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, minimum-scale=0.3, initial-scale=0.3">

  <!-- Site Metas -->
  <title>Registrar Paciente-Formar</title>
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Site Icons -->
  <link rel="shortcut icon" href="/images/formarico.png" type="image/x-icon">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/css/bootstrap.min.css">
  <!-- Pogo Slider CSS -->
  <!-- Site CSS -->
  <link rel="stylesheet" href="/css/styleav.css">
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="/css/responsive.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="/css/custom.css">
  <!-- Desplegable -->
  <link rel="stylesheet" href="/css/dropdown.css">
  <!-- Navar -->
  <link rel="stylesheet" href="/css/navvar.css">
  <!-- AulaVirtual -->
  <link rel="stylesheet" href="/css/aulavirtual.css">
  <!-- Icons -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/v4-shims.css">  

  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="home" style="position: relative; width:100%; max-width: 100%; overflow-x: hidden;" data-spy="scroll" data-target="#navbar-wd" oncontextmenu="return false;" data-offset="98">

  <!-- LOADER -->
  <div id="preloader">
    <div class="loader">
      <img src="/images/loader.gif" alt="#" />
    </div>
  </div>
  <!-- end loader -->
  <!-- END LOADER -->

  <!-- Start header -->
  <header class="top-header">
    <nav class="navbar header-nav navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="inicio"><img src="/images/logoaula.png" alt="image"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
          <span></span>
          <span></span>
          <span></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
            <ul class="nav">
            
            <?php
            session_start();
            if(isset($_SESSION['vip'])){
                echo'
                <li><a class="nav-link" href="turnos">Turnos Dados</a></li>
                <li><a class="nav-link" href="registrarprofesional">Registrar Profesionales</a></li>
                ';
            }
            ?>
            <li><a class="nav-link" href="calendar/index">Sacar Turnos</a></li>
            <?php
            session_start();
            if(isset($_SESSION['vip'])){
                echo'
                <li><a class="nav-link" href="cerrar_sesion_be">Cerrar Sesion</a></li>
                ';
            }
            ?>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  
<div style="text-align: center;">
  <hr>
  <h2>Registro Pacientes - FORMAR</h2>
  
<div style="width: 500px; display: inline-block; position: relative;">  


<form style="margin: auto;" method="POST" action="registrarpaciente_be.php" enctype="multipart/form-data">
				    <input required="" data-error="Porfavor ingresa tu Nombre Completo" type="text" placeholder="Nombre y Apellido" name="nombre_completo" tabindex="1" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%;"><br>
					<input required="" data-error="Porfavor ingresa una Edad" type="text" name="edad" placeholder="Edad" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%"><br>
					<input required="" data-error="Porfavor su DNI" type="text" name="dni" placeholder="DNI" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%"><br>
					<input required="" data-error="Porfavor ingresa su Direccion" type="text" name="direccion" placeholder="Direccion" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%"><br>
					<input required="" data-error="Porfavor ingresa tu Telefono" type="text" name="telefono" placeholder="Telefono" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%">
					<input required="" data-error="Porfavor ingresa tu Fecha de Nacimiento" type="text" name="fechanacimiento" placeholder="Fecha de Nacimiento" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%"><br>
					<select name="obrasocial" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%">
					                        <option selected="selected">Selecionar Obra Social</option>
                                            <option>APM</option>
                                            <option>Swiss Medical</option>
                                            <option>OSDE</option>
                                            <option>Luis Pasteur</option>
                                            <option>Apross</option>
                                            <option>Galeno</option>
                                            <option>ACA-Salud</option>
                                            <option>Prevencion Salud</option>
                                            <option>Visitar</option>
                                            <option>OSSEG</option>
                                            <option>Caja Notarial</option>
                                            <option>Caja de Abogados</option>
                                            <option>CPCE</option>
                                            <option>Daspu</option>
                                            <option>Federada Salud</option>
                                            </select>
                    <input required="" data-error="Porfavor su Plan" type="text" name="plan" placeholder="Plan" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%"><br>
                    <select name="situacion" style="border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 80%">
					                        <option selected="selected">Situacion Fiscal</option>
                                            <option>Exento</option>
                                            <option>Gravado</option>
                                            </select>
                                            <br>
                                            <br>
					<button placeholder="Registrarse" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Registrarse</button>
				</form>

</div> 
</body>

  <!-- ALL JS FILES -->
  <script src="/js/jquery.min.js"></script>
  <script src="/js/popper.min.js"></script>
  <script src="/js/bootstrap.min.js"></script>
  <!-- ALL PLUGINS -->
  <script src="/js/jquery.magnific-popup.min.js"></script>
  <script src="/js/jquery.pogo-slider.min.js"></script>
  <script src="/js/smoothscroll.js"></script>
  <script src="/js/isotope.min.js"></script>
  <script src="/js/images-loded.min.js"></script>
  <script src="/js/custom.js"></script>
</body>

</html>