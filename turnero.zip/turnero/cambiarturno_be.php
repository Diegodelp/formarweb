<?php 

include 'conexionturno_be.php';

$paciente = $_POST['paciente'];
$hora = $_POST['hora'];
$fecha = $_POST['fecha'];

$query = "UPDATE turnos SET hora_tomada='$hora', fecha_tomada='$fecha', WHERE id='$paciente'";
		

$cargaexito = mysqli_query($conexion, $query);

if ($cargaexito) {
    echo '
    <script> 
    alert ("Datos Cargados Correctamente");
    window.location = "../turnero/turnos"
    </script>
    ';
}

mysqli_close($conexion);

?>