<?php 

include 'db_connect.php';

$paciente = $_POST['paciente'];
$hora = $_POST['horac'];
$hora2 = $_POST['hora2c'];
$fecha = $_POST['fecha'];
$profesional = $_POST['profesional'];
$hora3 = $_POST['hora3c'];

$query = "DELETE FROM events WHERE id='$paciente'";
		

$cargaexito = mysqli_query($conexion, $query);

if ($cargaexito) {
    echo '
    <script> 
    alert ("Turno Eliminado Correctamente");
    window.location = "index"
    </script>
    ';
}

mysqli_close($conexion);

?>