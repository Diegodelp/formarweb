<?php 

include 'db_connect.php';

$paciente = $_POST['paciente'];
$hora = $_POST['horac'];
$hora2 = $_POST['hora2c'];
$fecha = $_POST['fecha'];
$profesional = $_POST['profesional'];
$hora3 = $_POST['hora3c'];

$query = "UPDATE events SET start_date='$fecha $hora', end_date='$fecha $hora2', fecha='$fecha', hora='$hora3', description='$profesional' WHERE id='$paciente'";
		

$cargaexito = mysqli_query($conexion, $query);

if ($cargaexito) {
    echo '
    <script> 
    alert ("Datos Cargados Correctamente");
    window.location = "index"
    </script>
    ';
}

mysqli_close($conexion);

?>