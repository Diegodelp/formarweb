<?php 

include('header.php');

session_start();
if(!isset($_SESSION['vip'])){
    echo' <script>
	alert("Debes Iniciar Sesion");
	window.location = "../login.php";
	</script>';
    
}


?>
<title>Turnos-Formar</title>
<link rel="shortcut icon" href="/images/formarico.png" type="image/x-icon">
<link rel="stylesheet" href="css/calendar.css">
<link rel="stylesheet" href="css/aulavirtual.css">
<!-- Icons -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/v4-shims.css">  

<?php include('container.php');?>
<div class="container">	
	<h2>Turnos Formar</h2>	
	<div class="page-header">
		<div class="pull-right form-inline">
			<div class="btn-group">
				<button class="btn btn-primary" data-calendar-nav="prev"><< Atrás</button>
				<button class="btn btn-default" data-calendar-nav="today">Hoy</button>
				<button class="btn btn-primary" data-calendar-nav="next">Siguiente >></button>
			</div>
			<div class="btn-group">
				<button class="btn btn-warning" data-calendar-view="year">A&ntilde;o</button>
				<button class="btn btn-warning active" data-calendar-view="month">Mes</button>
				<button class="btn btn-warning" data-calendar-view="week">Semana</button>
			</div>
		</div>
		<h3></h3>
	</div>
	<div class="row">
		<div class="col-md-9">
			<div id="showEventCalendar"></div>
		</div>
		<div class="col-md-3">
			<div class="container">
  <div id="myCarousel" class="carousel slide" data-interval="false" style="width:400px">
    <!-- Indicators -->

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item" style="margin-left: 70px; background-color: white;">
        	<div style="margin: auto; width: 900px;">
	    <h2 style="color: black">Obtener Turnos</h2>

  
<form method="POST" id="turno" action="sacarturnos_be.php">
<select name="paciente" id="paciente" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
        <?php
                include 'db_connect.php';
                $sqlpaciente = mysqli_query($conexion, "SELECT * FROM pacientes");
                $rowpaciente = mysqli_num_rows($sqlpaciente);
                echo '<option selected="selected">-Paciente-</option>';
                while ($rowpaciente = mysqli_fetch_array($sqlpaciente)){
                echo "
                <option value='".$rowpaciente['nombre_completo'] ."'>" .$rowpaciente['nombre_completo'] ."</option>" ;
                }
                ?>
    
</select>
<br>
<input type="email" name="email" id="email" placeholder="Ingrese su email" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
<br>
<a style="color: black">Si no estas en la lista, registrate</a> <a href="../registrarpaciente">aqui</a>
<br>
<select name="obrasocial" id="obrasocial" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
        <?php
                include 'db_connect.php';
                $sqlobra = mysqli_query($conexion, "SELECT * FROM pacientes");
                $rowobra = mysqli_num_rows($sqlobra);
                echo '<option selected="selected">-Selecionar Obra Social-</option>
                                            <option>APM</option>
                                            <option>Swiss Medical</option>
                                            <option>OSDE</option>
                                            <option>Luis Pasteur</option>
                                            <option>Apross</option>
                                            <option>Galeno</option>
                                            <option>ACA-Salud</option>
                                            <option>Prevencion Salud</option>
                                            <option>Visitar</option>
                                            <option>OSSEG</option>
                                            <option>Caja Notarial</option>
                                            <option>Caja de Abogados</option>
                                            <option>CPCE</option>
                                            <option>Daspu</option>
                                            <option>Federada Salud</option>';
                                            
                ?>
    
</select>
<br>
<select name="profesional" id="profesional" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
    <?php
                include 'db_connect.php';
                $sqlprofesional = mysqli_query($conexion, "SELECT * FROM profesionales");
                $rowprofesional = mysqli_num_rows($sqlprofesinal);
                echo '<option selected="selected">-Profesional-</option>';
                while ($rowprofesional = mysqli_fetch_array($sqlprofesional)){
                echo "
                <option value='".$rowprofesional['nombre_completo'] ."'>" .$rowprofesional['nombre_completo'] . ' - MP.' .$rowprofesional['matricula']."</option>" ;
                }
                ?>
</select>
<br>
<input type="date" name="fecha" id="fecha" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
<br>

<select name="hora" id="hora" class="hora" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
    <option value="" selected data-id="0" data-name="0">-Selecciona un Horario-</option>
    <option value="12:00:00" data-id="1" data-name="1">9:00Hs</option>
    <option value="12:45:00" data-id="2" data-name="2">9:45Hs</option>
    <option value="13:30:00" data-id="3" data-name="3">10:30Hs</option>
    <option value="14:15:00" data-id="4" data-name="4">11:15Hs</option>
    <option value="15:00:00" data-id="5"  data-name="5">12:00Hs</option>
    <option value="15:45:00" data-id="6" data-name="6">12:45Hs</option>
    <option value="16:30:00" data-id="7" data-name="7">13:30Hs</option>
    <option value="17:15:00" data-id="8" data-name="8">14:15Hs</option>
    <option value="18:00:00" data-id="9" data-name="9">15:00Hs</option>
    <option value="18:45:00" data-id="10" data-name="10">15:45Hs</option>
    <option value="19:30:00" data-id="11" data-name="11">16:30Hs</option>
    <option value="20:15:00" data-id="12" data-name="12">17:15Hs</option>
</select><br>
<select name="hora2" id="hora2" class"hora2" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 25.3%; display: none">
    <option value="" data-id="0" selected>-Selecciona un Horario-</option>
    <option value="12:45:00" >9:45Hs</option>
    <option value="13:30:00" >10:30Hs</option>
    <option value="14:15:00" >11:15Hs</option>
    <option value="15:00:00" >12:00Hs</option>
    <option value="15:45:00" >12:45Hs</option>
    <option value="16:30:00" >13:30Hs</option>
    <option value="17:15:00" >14:15Hs</option>
    <option value="18:00:00" >15:00Hs</option>
    <option value="18:45:00" >15:45Hs</option>
    <option value="19:30:00" >16:30Hs</option>
    <option value="20:15:00" >17:15Hs</option>
    <option value="21:00:00" >18:00Hs</option>
</select><br>
<select name="hora3" id="hora3" class"hora3" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 25.3%; display: none">
    <option value="" selected data-id="0" data-name="0">-Selecciona un Horario-</option>
    <option value="09:00Hs" data-id="1" data-name="1">9:00Hs</option>
    <option value="09:45Hs" data-id="2" data-name="2">9:45Hs</option>
    <option value="10:30Hs" data-id="3" data-name="3">10:30Hs</option>
    <option value="11:15Hs" data-id="4" data-name="4">11:15Hs</option>
    <option value="12:00Hs" data-id="5"  data-name="5">12:00Hs</option>
    <option value="12:45Hs" data-id="6" data-name="6">12:45Hs</option>
    <option value="13:30Hs" data-id="7" data-name="7">13:30Hs</option>
    <option value="14:15Hs" data-id="8" data-name="8">14:15Hs</option>
    <option value="15:00Hs" data-id="9" data-name="9">15:00Hs</option>
    <option value="15:45Hs" data-id="10" data-name="10">15:45Hs</option>
    <option value="16:30Hs" data-id="11" data-name="11">16:30Hs</option>
    <option value="17:15Hs" data-id="12" data-name="12">17:15Hs</option>
</select>
<select name="prestacion" id="prestacion" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
    <option value="Estetica">Estetica</option>
    <option value="Ortodoncia">Ortodoncia</option>
    <option value="Ortopedia">Ortopedia</option>
    <option value="Cirugia">Cirugia</option>
    <option value="Endodoncia">Endodoncia</option>
    <option value="Protesis">Protesis</option>
    <option value="Periodoncia">Periodoncia</option>
</select>
<br>
                                            <br>
					<button placeholder="Cambiar Turno" name="imprime" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Registrar Turno</button>
					
					<br>
					

</form>
<button name="imprimir" onclick="openWin()" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Imprimir Turno</button>
  </div>
      </div>
      
      <div class="item" style="margin-left: 70px; background-color: white;">
        	<div style="margin: auto; width: 900px;">
	    <h2 style="color: black">Eliminar Turnos</h2>
            <form method="POST" id="date" action="index">
            <h5 style="color: black">1)Elegir fecha a verificar</h5>
            <input type="date" name="date" id="date"  value="<?php echo date('Y-m-d');?>" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 1px; margin-bottom:4px; width: 30%">
            <br>
            <input type="submit" value="Verificar" style="background-color: #7ba4e3; color: white; border-radius: 10px;">
            </form>
  
            <form method="POST" id="turno" action="eliminarturnos_be.php">
            <select name="paciente" id="paciente" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
                    <?php
                            include 'db_connect.php';
                            $sqlpaciente = mysqli_query($conexion, "SELECT * FROM events WHERE fecha='{$_POST['date']}'");
                            $rowpaciente = mysqli_num_rows($sqlpaciente);
                            echo '<option selected="selected">-Paciente-</option>';
                            while ($rowpaciente = mysqli_fetch_array($sqlpaciente)){
                            echo "
                            <option value='".$rowpaciente['id'] ."'>" .$rowpaciente['title'] ."</option>" ;
                            }
                            ?>
                
            </select>
            <br>
                                                        <br>
            					<button placeholder="Cambiar Turno" name="imprime" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Eliminar Turno</button>
            					
            					<br>
            					
            
            </form>
                    <button name="imprimir" onclick="openWin()" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Imprimir Turno</button>
                      </div>
                          </div>

      <div class="item active" style="margin-left: 70px; background-color: white;">
                	<div style="margin: auto; width: 900px;">
	    <h2 style="color: black">Cambiar Turnos</h2>
	    
            <form method="POST" id="date" action="index">
            <h5 style="color: black">1)Elegir fecha a verificar</h5>
            <input type="date" name="date" id="date"  value="<?php echo date('Y-m-d');?>" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 1px; margin-bottom:4px; width: 30%">
            <br>
            <input type="submit" value="Verificar" style="background-color: #7ba4e3; color: white; border-radius: 10px;">
            </form>
            <form method="POST" id="turno" action="cambiarturno_be.php">
            <h5 style="color: black">2)Realizar cambio de turno</h5>
            <select name="paciente" id="paciente" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
                    <?php
                            include 'db_connect.php';
                            $sqlpaciente = mysqli_query($conexion, "SELECT * FROM events WHERE fecha='{$_POST['date']}'");
                            $rowpaciente = mysqli_num_rows($sqlpaciente);
                            echo '<option selected="selected">-Paciente-</option>';
                            while ($rowpaciente = mysqli_fetch_array($sqlpaciente)){
                            echo "
                            <option value='".$rowpaciente['id'] ."'>" .$rowpaciente['title'] ."</option>" ;
                            }
                            ?>
                
            </select>
            <br>
            <select name="obrasocial" id="obrasocial" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
                    <?php
                            include 'db_connect.php';
                            $sqlobra = mysqli_query($conexion, "SELECT * FROM pacientes");
                            $rowobra = mysqli_num_rows($sqlobra);
                            echo '<option selected="selected">-Selecionar Obra Social-</option>
                                                        <option>APM</option>
                                                        <option>Swiss Medical</option>
                                                        <option>OSDE</option>
                                                        <option>Luis Pasteur</option>
                                                        <option>Apross</option>
                                                        <option>Galeno</option>
                                                        <option>ACA-Salud</option>
                                                        <option>Prevencion Salud</option>
                                                        <option>Visitar</option>
                                                        <option>OSSEG</option>
                                                        <option>Caja Notarial</option>
                                                        <option>Caja de Abogados</option>
                                                        <option>CPCE</option>
                                                        <option>Daspu</option>
                                                        <option>Federada Salud</option>';
                                                        
                            ?>
                
            </select>
            <br>
            <select name="profesional" id="profesional" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
                <?php
                            include 'db_connect.php';
                            $sqlprofesional = mysqli_query($conexion, "SELECT * FROM profesionales");
                            $rowprofesional = mysqli_num_rows($sqlprofesinal);
                            echo '<option selected="selected">-Profesional-</option>';
                            while ($rowprofesional = mysqli_fetch_array($sqlprofesional)){
                            echo "
                            <option value='".$rowprofesional['nombre_completo'] ."'>" .$rowprofesional['nombre_completo'] . ' - MP.' .$rowprofesional['matricula']."</option>" ;
                            }
                            ?>
            </select>
            <br>
            <input type="date" name="fecha" value="<?php echo date('Y-m-d');?>" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
            <br>
            <script>
            window.onload=function() { 
              document.getElementById("horac").onchange=function() {
                document.getElementById("hora2c").selectedIndex=this.options[this.selectedIndex].getAttribute("data-id");
                    document.getElementById("hora3c").selectedIndex=this.options[this.selectedIndex].getAttribute("data-id");
              }
              document.getElementById("horac").onchange(); // trigger when loading
              
              document.getElementById("hora").onchange=function() {
                document.getElementById("hora2").selectedIndex=this.options[this.selectedIndex].getAttribute("data-id");
                document.getElementById("hora3").selectedIndex=this.options[this.selectedIndex].getAttribute("data-id");
              }
              document.getElementById("hora").onchange(); // trigger when loading
              
                
            
            
            
            }
            
            </script>
            <select name="horac" id="horac" class="horac" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
                <option value="" selected data-id="0">-Selecciona un Horario-</option>
                <option value="12:00:00" data-id="1">9:00Hs</option>
                <option value="12:45:00" data-id="2">9:45Hs</option>
                <option value="13:30:00" data-id="3">10:30Hs</option>
                <option value="14:15:00" data-id="4">11:15Hs</option>
                <option value="15:00:00" data-id="5">12:00Hs</option>
                <option value="15:45:00" data-id="6">12:45Hs</option>
                <option value="16:30:00" data-id="7">13:30Hs</option>
                <option value="17:15:00" data-id="8">14:15Hs</option>
                <option value="18:00:00" data-id="9">15:00Hs</option>
                <option value="18:45:00" data-id="10">15:45Hs</option>
                <option value="19:30:00" data-id="11">16:30Hs</option>
                <option value="20:15:00" data-id="12">17:15Hs</option>
            </select><br>
            <select name="hora2c" id="hora2c" class"hora2c" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 25.3%; display: none">
                <option value="" selected>-Selecciona un Horario-</option>
                <option value="12:45:00">9:45Hs</option>
                <option value="13:30:00">10:30Hs</option>
                <option value="14:15:00">11:15Hs</option>
                <option value="15:00:00">12:00Hs</option>
                <option value="15:45:00">12:45Hs</option>
                <option value="16:30:00">13:30Hs</option>
                <option value="17:15:00">14:15Hs</option>
                <option value="18:00:00">15:00Hs</option>
                <option value="18:45:00">15:45Hs</option>
                <option value="19:30:00">16:30Hs</option>
                <option value="20:15:00">17:15Hs</option>
                <option value="21:00:00">18:00Hs</option>
            </select>
            <select name="hora3c" id="hora3c" class="hora3c" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%; display: none">
                <option value="" selected data-id="0" data-name="0">-Selecciona un Horario-</option>
                <option value="09:00Hs" data-id="1" data-name="1">9:00Hs</option>
                <option value="09:45Hs" data-id="2" data-name="2">9:45Hs</option>
                <option value="10:30Hs" data-id="3" data-name="3">10:30Hs</option>
                <option value="11:15Hs" data-id="4" data-name="4">11:15Hs</option>
                <option value="12:00Hs" data-id="5"  data-name="5">12:00Hs</option>
                <option value="12:45Hs" data-id="6" data-name="6">12:45Hs</option>
                <option value="13:30Hs" data-id="7" data-name="7">13:30Hs</option>
                <option value="14:15Hs" data-id="8" data-name="8">14:15Hs</option>
                <option value="15:00Hs" data-id="9" data-name="9">15:00Hs</option>
                <option value="15:45Hs" data-id="10" data-name="10">15:45Hs</option>
                <option value="16:30Hs" data-id="11" data-name="11">16:30Hs</option>
                <option value="17:15Hs" data-id="12" data-name="12">17:15Hs</option>
            </select><br>
            <select name="prestacion" id="prestacion" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
                <option value="Estetica">Estetica</option>
                <option value="Ortodoncia">Ortodoncia</option>
                <option value="Ortopedia">Ortopedia</option>
                <option value="Cirugia">Cirugia</option>
                <option value="Endodoncia">Endodoncia</option>
                <option value="Protesis">Protesis</option>
                <option value="Periodoncia">Periodoncia</option>
            </select>
            <br>
                                                        <br>
            					<button placeholder="Cambiar Turno" name="imprime" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Cambiar Turno</button>
            					
            					<br>
            					
            
            </form>
                            <button name="imprimir" onclick="openWin()" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Imprimir Turno</button>
                              </div>'; ?>
                                  </div>
                                
                                </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" style="background-image:none;" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" style="color: black;"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" style="background-image:none;" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" style="color: black;"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
  </div>  
</body>

<script type="text/javascript">
  function openWin()
  {
              document.getElementById('turno').onsubmit = function() { 
        	console.log(document.getElementById('paciente').value);
        	console.log(document.getElementById('profesional').value);
        	console.log(document.getElementById('obrasocial').value);
        	console.log(document.getElementById('fecha').value);
        	console.log(document.getElementById('hora').value);
        	console.log(document.getElementById('prestacion').value);
          return false;
        };
      var logo = '<img id="logo" src="/images/logo.png" alt="image"><br>';        
      var paciente = document.getElementById('paciente').value;
      var profesional = document.getElementById('profesional').value;
      var obrasocial = document.getElementById('obrasocial').value;
      var fecha = document.getElementById('fecha').value;
      var hora = document.getElementById('hora').value;
      var prestacion = document.getElementById('prestacion').value;
    var myWindow=window.open('','','width=400,height=300');
    myWindow.document.write(logo);
    myWindow.document.write('<h2>Turno</h2>');
    myWindow.document.write('Paciente: ' + paciente);
    myWindow.document.write('<br>Profesional: ' + profesional);
    myWindow.document.write('<br>Obra Social: ' + obrasocial);
    myWindow.document.write('<br>Fecha: ' + fecha);
    myWindow.document.write('<br>Hora: ' + hora);
    myWindow.document.write('<br>Prestacion: ' + prestacion);
    
    myWindow.document.close();
myWindow.focus();
myWindow.print();
myWindow.close();
    
  }
</script>
		</div>
	</div>	

				
	</div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
<script type="text/javascript" src="js/calendar.js"></script>
<script type="text/javascript" src="js/events.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php include('footer.php');?>
