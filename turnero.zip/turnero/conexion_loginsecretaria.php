<?php

	$usuario = "i6852879_wp1";
	$password = "formarmartinez";
	$servidor = "localhost";
	$basededatos = "login-register-db";
	
	// creaci贸n de la conexi贸n a la base de datos con mysql_connect()
	$conexion = mysqli_connect( $servidor, $usuario, $password, $basededatos) or die ("No se ha podido conectar al servidor de Base de datos");
?>	