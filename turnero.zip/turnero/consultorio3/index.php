<?php 

include('header.php');




?>
<title>Turnos-Formar</title>
<link rel="shortcut icon" href="/images/formarico.png" type="image/x-icon">
<link rel="stylesheet" href="css/calendar.css">
<link rel="stylesheet" href="css/aulavirtual.css">
<!-- Icons -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/v4-shims.css">  

<?php include('container.php');?>
<div class="container">	
    <h2>FORMAR - Consultorio 3</h2>		
	<div class="page-header">
		<div class="pull-right form-inline">
			<div class="btn-group">
				<button class="btn btn-primary" data-calendar-nav="prev"><< Atrás</button>
				<button class="btn btn-default" data-calendar-nav="today">Hoy</button>
				<button class="btn btn-primary" data-calendar-nav="next">Siguiente >></button>
			</div>
			<div class="btn-group">
				<button class="btn btn-warning" data-calendar-view="year">A&ntilde;o</button>
				<button class="btn btn-warning active" data-calendar-view="month">Mes</button>
				<button class="btn btn-warning" data-calendar-view="week">Semana</button>
			</div>
		</div>
		<h3></h3>
	</div>
	<div class="row">
		<div class="col-md-9">
			<div id="showEventCalendar"></div>
		</div>
		<div class="col-md-3">
			<div class="container">
  <div id="myCarousel" class="carousel slide" data-interval="false" style="width:400px">
    <!-- Indicators -->

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active" style="margin-left: 70px; background-color: white;">
        	<div style="margin: auto; width: 900px;">
	    <h2 style="color: black">Obtener Turnos</h2>

  
<form method="POST" id="turno" action="sacarturnos_be.php">
<select name="paciente" id="paciente" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
        <?php
                include 'db_connect.php';
                $sqlpaciente = mysqli_query($conexion, "SELECT * FROM pacientes");
                $rowpaciente = mysqli_num_rows($sqlpaciente);
                echo '<option selected="selected">-Paciente-</option>';
                while ($rowpaciente = mysqli_fetch_array($sqlpaciente)){
                echo "
                <option value='".$rowpaciente['nombre_completo'] ."'>" .$rowpaciente['nombre_completo'] ."</option>" ;
                }
                ?>
    
</select>
<br>
<input type="email" name="email" id="email" placeholder="Ingrese su email" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
<br>
<a style="color: black">Si no estas en la lista, registrate</a> <a href="../registrarpaciente">aqui</a>
<br>
<select name="obrasocial" id="obrasocial" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%">
        <?php
                include 'db_connect.php';
                $sqlobra = mysqli_query($conexion, "SELECT * FROM pacientes");
                $rowobra = mysqli_num_rows($sqlobra);
                echo '<option selected="selected">-Selecionar Obra Social-</option>
                                            <option>APM</option>
                                            <option>Swiss Medical</option>
                                            <option>OSDE</option>
                                            <option>Luis Pasteur</option>
                                            <option>Apross</option>
                                            <option>Galeno</option>
                                            <option>ACA-Salud</option>
                                            <option>Prevencion Salud</option>
                                            <option>Visitar</option>
                                            <option>OSSEG</option>
                                            <option>Caja Notarial</option>
                                            <option>Caja de Abogados</option>
                                            <option>CPCE</option>
                                            <option>Daspu</option>
                                            <option>Federada Salud</option>';
                                            
                ?>
    
</select>
<br>
<select name="profesional" id="profesional" style="color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
    <option value="-Consultorio 3-" selected >-Consultorio 3-</option>
</select>
<br>
<input type="date" name="fecha" id="fecha" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
<br>

<select name="hora" id="hora" class="hora" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
    <option value="" selected data-id="0" data-name="0">-Selecciona un Horario-</option>
    <option value="12:30:00" data-id="1" data-name="1">9:30Hs</option>
    <option value="13:15:00" data-id="2" data-name="2">10:15Hs</option>
    <option value="14:00:00" data-id="3" data-name="3">11:00Hs</option>
    <option value="14:45:00" data-id="4" data-name="4">11:45Hs</option>
    <option value="15:30:00" data-id="5"  data-name="5">12:30Hs</option>
    <option value="16:15:00" data-id="6" data-name="6">13:15Hs</option>
    <option value="17:00:00" data-id="7" data-name="7">14:00Hs</option>
    <option value="17:45:00" data-id="8" data-name="8">14:45Hs</option>
    <option value="18:30:00" data-id="9" data-name="9">15:30Hs</option>
    <option value="19:15:00" data-id="10" data-name="10">16:15Hs</option>
    <option value="20:00:00" data-id="11" data-name="11">17:00Hs</option>
    <option value="20:45:00" data-id="12" data-name="12">17:45Hs</option>
</select><br>
<select name="hora2" id="hora2" class"hora2" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 25.3%; display: none">
    <option value="" data-id="0" selected>-Selecciona un Horario-</option>
    <option value="13:15:00" >10:15Hs</option>
    <option value="14:00:00" >11:00Hs</option>
    <option value="14:45:00" >11:45Hs</option>
    <option value="15:30:00" >12:30Hs</option>
    <option value="16:15:00" >13:15Hs</option>
    <option value="17:00:00" >13:30Hs</option>
    <option value="17:45:00" >14:15Hs</option>
    <option value="18:30:00" >15:00Hs</option>
    <option value="19:15:00" >15:45Hs</option>
    <option value="20:00:00" >16:30Hs</option>
    <option value="20:45:00" >17:15Hs</option>
    <option value="21:30:00" >18:00Hs</option>
</select><br>
<select name="hora3" id="hora3" class"hora3" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 25.3%; display: none">
    <option value="" selected data-id="0" data-name="0">-Selecciona un Horario-</option>
    <option value="09:30Hs" data-id="1" data-name="1">9:00Hs</option>
    <option value="10:15Hs" data-id="2" data-name="2">9:45Hs</option>
    <option value="11:00Hs" data-id="3" data-name="3">10:30Hs</option>
    <option value="11:45Hs" data-id="4" data-name="4">11:15Hs</option>
    <option value="12:30Hs" data-id="5"  data-name="5">12:00Hs</option>
    <option value="13:15Hs" data-id="6" data-name="6">12:45Hs</option>
    <option value="14:00Hs" data-id="7" data-name="7">13:30Hs</option>
    <option value="14:45Hs" data-id="8" data-name="8">14:15Hs</option>
    <option value="15:30Hs" data-id="9" data-name="9">15:00Hs</option>
    <option value="16:15Hs" data-id="10" data-name="10">15:45Hs</option>
    <option value="17:00Hs" data-id="11" data-name="11">16:30Hs</option>
    <option value="17:45Hs" data-id="12" data-name="12">17:15Hs</option>
</select>
<select name="prestacion" id="prestacion" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 30%;">
    <option value="Estetica">Estetica</option>
    <option value="Ortodoncia">Ortodoncia</option>
    <option value="Ortopedia">Ortopedia</option>
    <option value="Cirugia">Cirugia</option>
    <option value="Endodoncia">Endodoncia</option>
    <option value="Protesis">Protesis</option>
    <option value="Periodoncia">Periodoncia</option>
</select>
<br>
                                            <br>
					<button placeholder="Cambiar Turno" name="imprime" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Registrar Turno</button>
					
					<br>
					

</form>
<button name="imprimir" onclick="openWin()" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Imprimir Turno</button>
  </div>
      </div>
      
      
            <script>
            window.onload=function() { 
              
              document.getElementById("hora").onchange=function() {
                document.getElementById("hora2").selectedIndex=this.options[this.selectedIndex].getAttribute("data-id");
                document.getElementById("hora3").selectedIndex=this.options[this.selectedIndex].getAttribute("data-id");
              }
              document.getElementById("hora").onchange(); // trigger when loading
              
                
            
            
            
            }
            
            </script>
        
  </div>
</div>
  </div>  
</body>

<script type="text/javascript">
  function openWin()
  {
              document.getElementById('turno').onsubmit = function() { 
        	console.log(document.getElementById('paciente').value);
        	console.log(document.getElementById('profesional').value);
        	console.log(document.getElementById('obrasocial').value);
        	console.log(document.getElementById('fecha').value);
        	console.log(document.getElementById('hora').value);
        	console.log(document.getElementById('prestacion').value);
          return false;
        };
      var logo = '<img id="logo" src="/images/logo.png" alt="image"><br>';        
      var paciente = document.getElementById('paciente').value;
      var profesional = document.getElementById('profesional').value;
      var obrasocial = document.getElementById('obrasocial').value;
      var fecha = document.getElementById('fecha').value;
      var hora = document.getElementById('hora').value;
      var prestacion = document.getElementById('prestacion').value;
    var myWindow=window.open('','','width=400,height=300');
    myWindow.document.write(logo);
    myWindow.document.write('<h2>Turno</h2>');
    myWindow.document.write('Paciente: ' + paciente);
    myWindow.document.write('<br>Profesional: ' + profesional);
    myWindow.document.write('<br>Obra Social: ' + obrasocial);
    myWindow.document.write('<br>Fecha: ' + fecha);
    myWindow.document.write('<br>Hora: ' + hora);
    myWindow.document.write('<br>Prestacion: ' + prestacion);
    
    myWindow.document.close();
myWindow.focus();
myWindow.print();
myWindow.close();
    
  }
</script>
		</div>
	</div>	

				
	</div>
</div>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
<script type="text/javascript" src="js/calendar.js"></script>
<script type="text/javascript" src="js/events.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php include('footer.php');?>
