<!DOCTYPE html>
<html style="max-width: 100%; overflow-x: hidden;" lang="en">
<!-- Basic -->
<script>
     window.addEventListener("load",function() {
  // Set a timeout...
  setTimeout(function(){
    // Hide the address bar!
    window.scrollTo(0, 1);
  }, 0);
}); 

var preventDefault = function(e) {
    e.preventDefault();
    return false;
};
document.addEventListener('touchmove',preventDefault,false);
document.body.addEventListener('touchmove',preventDefault,true);
window.addEventListener('touchmove',preventDefault,true);
    </script>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, minimum-scale=0.3, initial-scale=0.3">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />

  <!-- Site Metas -->
  <title>Sacar Turnos-Formar</title>
  <meta name="keywords" content="">
  <meta name="description" content="">
  <meta name="author" content="">

  <!-- Site Icons -->
  <link rel="shortcut icon" href="/images/formarico.png" type="image/x-icon">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="/css/bootstrap.min.css">
  <!-- Pogo Slider CSS -->
  <!-- Site CSS -->
  <link rel="stylesheet" href="/css/styleav.css">
  <!-- Responsive CSS -->
  <link rel="stylesheet" href="/css/responsive.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="/css/custom.css">
  <!-- Desplegable -->
  <link rel="stylesheet" href="/css/dropdown.css">
  <!-- Navar -->
  <link rel="stylesheet" href="/css/navvar.css">
  <!-- AulaVirtual -->
  <link rel="stylesheet" href="/css/aulavirtual.css">
  <!-- Icons -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/v4-shims.css">  

  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body id="home" style="position: relative; width:100%; max-width: 100%; overflow-x: hidden;" data-spy="scroll" data-target="#navbar-wd" data-offset="98">

  <!-- LOADER -->
  <div id="preloader">
    <div class="loader">
      <img src="/images/loader.gif" alt="#" />
    </div>
  </div>
  <!-- end loader -->
  <!-- END LOADER -->

  <!-- Start header -->
  <header class="top-header">
    <nav class="navbar header-nav navbar-expand-lg">
      <div class="container-fluid">
        <a class="navbar-brand" href="inicio"><img id="logo" src="/images/logo.png" alt="image"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-wd" aria-controls="navbar-wd" aria-expanded="false" aria-label="Toggle navigation">
          <span></span>
          <span></span>
          <span></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbar-wd">
            <ul class="nav">
            
            <?php/*
            session_start();
            if(isset($_SESSION['vip'])){
                echo'
                <li><a class="nav-link" href="turnos">Turnos Dados</a></li>
                <li><a class="nav-link" href="registrarprofesional">Registrar Profesionales</a></li>
                <li><a class="nav-link" href="registrarpaciente">Registrar Pacientes</a></li>
                <li><a class="nav-link" href="cerrar_sesion_be">Cerrar Sesion</a></li>
                ';
            }*/
            ?>
        
          </ul>
        </div>
      </div>
    </nav>
  </header>

<style>


.container {
  position: relative;
  width: 30%;
  display: fixed
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
  border-radius: 10px;
}



.container:hover .image {
  opacity: 0.5;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}

.container:hover .middle {
  opacity: 1;
}


</style>
</head>
<body>
<br>
<br>
<h2 style="text-align:center">FORMAR - Turnos</h2>
<hr>
<br>
<div style="position: relative;display: flex; text-align: center">
    <br>
<div class="container">
  <a href="/turnero/consultorio1/index"><img src="Consultorio 1.png" alt="Avatar" class="image" style="width:100%"></a>

</div><div class="container">
  <a href="/turnero/consultorio2/index"><img src="Consultorio 2.png" alt="Avatar" class="image" style="width:100%"></a>

</div><div class="container">
  <a href="/turnero/consultorio3/index"><img src="Consultorio 3.png" alt="Avatar" class="image" style="width:100%"></a>

</div></div>

  <script src="/js/jquery.min.js"></script>
  <script src="/js/popper.min.js"></script>
  <script src="/js/bootstrap.min.js"></script>
  <!-- ALL PLUGINS -->
  <script src="/js/jquery.magnific-popup.min.js"></script>
  <script src="/js/jquery.pogo-slider.min.js"></script>
  <script src="/js/smoothscroll.js"></script>
  <script src="/js/isotope.min.js"></script>
  <script src="/js/images-loded.min.js"></script>
  <script src="/js/custom.js"></script>
  <script src="/js/togglefullscreen.js"></script>
</body>

</html>