<?php 

include 'conexionturno_be.php';

$nombre = $_POST['nombre_completo'];
$edad = $_POST['edad'];
$dni = $_POST['dni'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$fechanacimiento = $_POST['fechanacimiento'];
$obrasocial = $_POST['obrasocial'];
$plan = $_POST['plan'];
$situacion = $_POST['situacion'];

$query = "INSERT INTO pacientes(nombre_completo, edad, dni, direccion, telefono, fecha_nacimiento, obra_social, plan, situacion)
            VALUES('$nombre', '$edad', '$dni', '$direccion', '$telefono', '$fechanacimiento', '$obrasocial', '$plan', '$situacion')";
            
		

$cargaexito = mysqli_query($conexion, $query);

if ($cargaexito) {
    echo '
    <script> 
    alert ("Datos Cargados Correctamente");
    window.location = "../turnero/calendar/sacar_turnos"
    </script>
    ';
}

mysqli_close($conexion);

?>