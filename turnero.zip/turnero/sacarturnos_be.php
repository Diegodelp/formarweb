<?php 

include 'conexionturno_be.php';

$paciente = $_POST['paciente'];
$profesional = $_POST['profesional'];
$obrasocial = $_POST['obrasocial'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$email =$_POST['email'];
$prestacion = $_POST['prestacion'];

$query = "INSERT INTO turnos(nombre_paciente, fecha_tomada, hora_tomada, nombre_profesional, tipo_prestacion, obra_social)
            VALUES('$paciente', '$fecha', '$hora', '$profesional', '$prestacion', '$obrasocial')";
            
$verificar_fecha = mysqli_query($conexion, "SELECT * FROM turnos WHERE fecha_tomada='$fecha' AND hora_tomada='$hora' AND nombre_profesional='$profesional'");	

if(mysqli_num_rows($verificar_fecha) > 0){
    echo '
    <script> 
    alert("Este horario ya esta en uso");
    window.location = "sacarturnos";
    </script>
    ';
    exit();
}

$cargaexito = mysqli_query($conexion, $query);



if ($cargaexito) {
    echo '
    <script> 
    alert ("Datos Cargados Correctamente");
    window.location = "sacarturnos"
    </script>
    ';
    
$to = $email;
$subject = "Turno de $prestacion - Formar";
$message = "Has sacado turno para el dia $fecha a las $hora";
$headers = "From: asociacion.formar.odontologia@gmail.com";
 
mail($to, $subject, $message, $headers);
}

mysqli_close($conexion);

?>