<?php 

include 'conexionturno_be.php';

$nombre = $_POST['nombre_completo'];
$edad = $_POST['edad'];
$dni = $_POST['dni'];
$fechanacimiento = $_POST['fechanacimiento'];
$matricula = $_POST['matricula'];

$query = "INSERT INTO profesionales(nombre_completo, edad, dni, fecha_nacimiento, matricula)
            VALUES('$nombre', '$edad', '$dni', '$fechanacimiento', '$matricula')";
            
		

$cargaexito = mysqli_query($conexion, $query);

if ($cargaexito) {
    echo '
    <script> 
    alert ("Datos Cargados Correctamente");
    window.location = "../turnero/sacarturnos"
    </script>
    ';
}

mysqli_close($conexion);

?>