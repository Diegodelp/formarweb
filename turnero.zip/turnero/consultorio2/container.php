</head>
<body class="">
<div role="navigation" class="navbar navbar-default navbar-static-top">
      <div class="container">
            <a class="navbar-brand" style="padding:20px" href="inicio"><img src="/images/logo.png" alt="image" style="display: block; margin-left: 3px;width: 60%;margin-top: -17px;margin-right: 3px;"></a> 
        <div class="navbar-header">
          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <?php if (isset($_SESSION['vip'])) { echo '<li class="active"><a href="http://www.formarodontologia.com/turnero/calendar/index">Inicio</a></li>
            <li><a href="http://www.formarodontologia.com/odontograma/index">Pacientes</a></li>';}else 
            echo '<li class="active"><a href="http://www.formarodontologia.com/turnero/calendar/sacar_turnos">Inicio</a></li>';?>
            <?php if (isset($_SESSION['vip'])) { echo '<li><a href="../cerrar_sesion_be">Salir <i class="fas fa-sign-out-alt"></i></a></li>';} ?>
          </ul>
         
        </div><!--/.nav-collapse -->
      </div>
    </div>
	
	<div class="container" style="min-height:500px;">
	<div class=''>
	</div>