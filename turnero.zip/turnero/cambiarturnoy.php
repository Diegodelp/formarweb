<html>
    
    <body>
        
        <form method="POST" action="cambiarturno_be.php">
            <select name="paciente" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
                
                <?php
                include 'conexionturno_be.php';
        $sql = mysqli_query($conexion, "SELECT * FROM turnos WHERE fecha_tomada='{$_POST['fecha']}' AND nombre_profesional='Yanina Galopo'");
        $row = mysqli_num_rows($sql);
            while ($row = mysqli_fetch_array($sql)){
                echo '<option value="'.$row['nombre_paciente'] .'">'.$row['nombre_paciente'] .' - ' .$row['nombre_profesional'] .' - '.$row['fecha_tomada'].'</option>' ;
                }
                ?>
            </select>
            <br>
                <select name="hora" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
                    <option value="9:00hs">9:00hs</option>
                    <option value="9:45hs">9:45hs</option>
                    <option value="10:30hs">10:30hs</option>
                    <option value="11:15hs">11:15hs</option>
                    <option value="12:00hs">12:00hs</option>
                    <option value="12:45hs">12:45hs</option>
                    <option value="13:30hs">13:30hs</option>
                    <option value="14:45hs">14:15hs</option>
                    <option value="15:00hs">15:00hs</option>
                    <option value="15:45hs">15:45hs</option>
                    <option value="16:30hs">16:30hs</option>
                    <option value="17:15hs">17:15hs</option>
                </select>
            <br>
            <input type="date" name="fecha" style="text-align:center; color: black; border-style: solid;  border-color: gray; border-width: 2px; border-radius: 5px; padding: 5px; margin-top: 10px; width: 50%;">
            <br>
            <br>
            <button type="submit" name="cambiarturno" placeholder="Cambiar" style="background-color: #7ba4e3; color: white; border-radius: 10px;">Cambiar Turno</button>
        </form>
        
        
    </body>
    
    
</html>