<?php
include_once("db_connect.php");
$sqlEvents = "SELECT id, title, description, start_date, hora, end_date FROM events1 LIMIT 20";
$resultset = mysqli_query($conexion, $sqlEvents) or die("database error:". mysqli_error($conexion));
$calendar = array();
while( $rows = mysqli_fetch_assoc($resultset) ) {	
	// convert  date to milliseconds
	$start = strtotime($rows['start_date']) * 1000;
	$end = strtotime($rows['end_date']) * 1000;	
	$hora =  $rows['hora'];
 	$calendar[] = array(
        'id' =>$rows['id'],
        'title' => $rows['title'],
        'description' => $rows['description'],
        'url' => "#",
		"class" => 'event-important',
        'start' => "$start",
        'end' => "$end",
        'hora' => $hora
    );
}
$calendarData = array(
	"success" => 1,	
    "result"=>$calendar);
echo json_encode($calendarData);
exit;
?>