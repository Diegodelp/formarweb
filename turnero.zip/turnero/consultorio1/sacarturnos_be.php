<?php 

include 'db_connect.php';

$paciente = $_POST['paciente'];
$profesional = $_POST['profesional'];
$obrasocial = $_POST['obrasocial'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$email =$_POST['email'];
$prestacion = $_POST['prestacion'];
$status = "1";
$hora2 = $_POST['hora2'];
$hora3 = $_POST['hora3'];

$verificar_fecha = mysqli_query($conexion, "SELECT * FROM events1 WHERE hora='$hora3' AND fecha='$fecha' AND description='$profesional'");	


if(mysqli_num_rows($verificar_fecha) > 0){
    echo '
    <script> 
    alert("Este horario ya esta en uso");
    window.location = "index";
    </script>
    ';
    exit();
}
$query = "INSERT INTO events1(title, description, start_date, end_date, hora, fecha, created, obra_social, status)
            VALUES('$paciente', '$profesional', '$fecha $hora', '$fecha $hora2', '$hora3', '$fecha', '$fecha $hora','$obrasocial', '$status')";
$cargaexito = mysqli_query($conexion, $query);

if ($cargaexito) {
    echo '
    <script> 
    alert ("Datos Cargados Correctamente");
    window.location = "index"
    </script>
    ';
    
$to = $email;
$subject = "Turno de $prestacion - Formar";
$message = "Has sacado turno para el dia $fecha a las $hora";
$headers = "From: asociacion.formar.odontologia@gmail.com";
 
mail($to, $subject, $message, $headers);
}

mysqli_close($conexion);

?>